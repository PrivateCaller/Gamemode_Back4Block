//-----------------------------------
//- Flash Grenade
//- By AGlass0fMilk
//- Version 1.1
//- Revised 6:00 PM 3/25/2010
//-
//- Bug fixes:
//- Took out "deafen" sound
//- Deafened forever after a while
//-----------------------------------

//datablock AudioProfile(FlashDeafenSound)
//{
//   filename = "./deafen.wav";
//   description = Audio2D;
//   preload = false;
///};

datablock AudioProfile(FlashgrenadeExplosionSound)
{
   filename    = "./flashbang.wav";
   description = AudioClosest3d;
   preload = false;
};

datablock AudioProfile(FlashgrenadeBounceSound)
{
   filename    = "./FlashgrenadeBounce.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(FlashgrenadeFireSound)
{
   filename    = "./FlashgrenadeFire.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock DebrisData(FlashgrenadePinDebris)
{
	shapeFile = "./FlashgrenadePin.dts";
	lifetime = 5.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};

datablock ParticleData(FlashgrenadeExplosionParticle)
{
	dragCoefficient		= 1.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= -0.2;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 4000;
	lifetimeVarianceMS	= 3990;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
	colors[0]	= "0.2 0.2 0.2 1.0";
	colors[1]	= "0.25 0.25 0.25 0.2";
   colors[2]	= "0.4 0.4 0.4 0.0";

	sizes[0]	= 2.0;
	sizes[1]	= 10.0;
   sizes[2]	= 13.0;

	times[0]	= 0.0;
	times[1]	= 0.1;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(flashgrenadeExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   lifeTimeMS	   = 21;
   ejectionVelocity = 10;
   velocityVariance = 1.0;
   ejectionOffset   = 1.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 90;
   overrideAdvance = false;
   particles = "flashgrenadeExplosionParticle";
};

datablock ParticleData(flashgrenadeExplosionParticle2)
{
	dragCoefficient		= 1.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= -0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 4000;
	lifetimeVarianceMS	= 3990;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
	colors[0]	= "0.2 0.2 0.2 0.0";
	colors[1]	= "0.25 0.25 0.25 0.2";
   colors[2]	= "0.4 0.4 0.4 0.0";

	sizes[0]	= 2.0;
	sizes[1]	= 10.0;
   sizes[2]	= 3.0;

	times[0]	= 0.0;
	times[1]	= 0.1;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(flashgrenadeExplosionEmitter2)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 0;
   lifetimeMS       = 120;
   ejectionVelocity = 15;
   velocityVariance = 5.0;
   ejectionOffset   = 0.0;
   thetaMin         = 85;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "flashgrenadeExplosionParticle2";
};



datablock ParticleData(flashgrenadeExplosionParticle3)
{
	dragCoefficient		= 1.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= -0.2;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 4000;
	lifetimeVarianceMS	= 3990;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/cloud";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
	colors[0]	= "0.2 0.2 0.2 0.0";
	colors[1]	= "0.25 0.25 0.25 0.2";
   colors[2]	= "0.4 0.4 0.4 0.0";

	sizes[0]	= 2.0;
	sizes[1]	= 10.0;
   sizes[2]	= 13.0;

	times[0]	= 0.0;
	times[1]	= 0.1;
   times[2]	= 1.0;
};

datablock ParticleEmitterData(flashgrenadeExplosionEmitter3)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   lifetimeMS       = 150;
   ejectionVelocity = 20;
   velocityVariance = 5.0;
   ejectionOffset   = 0.0;
   thetaMin         = 85;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "flashgrenadeExplosionParticle3";
};

datablock ParticleData(flashgrenadeExplosionParticle4)
{
	dragCoefficient		= 0.1;
	windCoefficient		= 0.0;
	gravityCoefficient	= 4.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 1000;
	lifetimeVarianceMS	= 500;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= true;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/chunk";
	//animTexName		= "~/data/particles/cloud";

	// Interpolation variables
	colors[0]	= "0.1 0.1 0.1 1.0";
	colors[1]	= "0.2 0.2 0.2 0.0";
	sizes[0]	= 0.5;
	sizes[1]	= 0.13;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(flashgrenadeExplosionEmitter4)
{
   ejectionPeriodMS = 1;
   timeMultiple     = 10;
   periodVarianceMS = 0;
   lifetimeMS       = 15;
   ejectionVelocity = 35;
   velocityVariance = 5.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "flashgrenadeExplosionParticle4";
};

datablock ExplosionData(flashgrenadeExplosion)
{
   explosionShape = "Add-Ons/Weapon_Rocket Launcher/explosionSphere1.dts";
   lifeTimeMS = 150;

   soundProfile = flashgrenadeExplosionSound;
   
   emitter[0] = flashgrenadeExplosionEmitter3;
   emitter[1] = flashgrenadeExplosionEmitter2;
   emitter[2] = flashgrenadeExplosionEmitter4;
   //emitter[1] = "";
   //emitter[2] = "";
   //emitter[0] = "";

   particleEmitter = flashgrenadeExplosionEmitter;
   particleDensity = 10;
//   particleDensity = 0;
   particleRadius = 1.0;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "30.0 30.0 30.0";
   camShakeAmp = "7 7 7";
   camShakeDuration = 4;
   camShakeRadius = 20.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 1;
   impulseForce = 0;

   //radius damage
   damageRadius = 15;
   radiusDamage = 0;

};

//projectile
AddDamageType("flashgrenadeDirect",   '<bitmap:add-ons/weapon_flashgrenade/ci_flashgrenade> %1',    '%2 <bitmap:add-ons/weapon_flashgrenade/ci_flashgrenade> %1',1,1);
AddDamageType("flashgrenadeRadius",   '<bitmap:add-ons/weapon_flashgrenade/ci_flashgrenade> %1',    '%2 <bitmap:add-ons/weapon_flashgrenade/ci_flashgrenade> %1',1,0);
datablock ProjectileData(flashgrenadeProjectile)
{
   projectileShapeName = "./flashgrenadeProjectile.dts";
   directDamage        = 0;
   directDamageType  = $DamageType::flashgrenadeDirect;
   radiusDamage = 0;
   radiusDamageType  = $DamageType::flashgrenadeRadius;
   impactImpulse	   = 200;
   verticalImpulse	   = 200;
   explosion           = flashgrenadeExplosion;
   //particleEmitter     = flashgrenadeTrailEmitter;

   brickExplosionRadius = 10;
   brickExplosionImpact = false; //destroy a brick if we hit it directly?
   brickExplosionForce  = 25;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   muzzleVelocity      = 30;
   velInheritFactor    = 0;
   explodeOnDeath = true;

   armingDelay         = 2500; 
   lifetime            = 2500;
   fadeDelay           = 3000;
   bounceElasticity    = 0.4;
   bounceFriction      = 0.3;
   isBallistic         = true;
   gravityMod = 1.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "Flash Grenade";
};

//////////
// item //
//////////
datablock ItemData(flashgrenadeItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./flashgrenade.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Flash Grenade";
	iconName = "./icon_flashgrenade";
	doColorShift = false;
	colorShiftColor = "0.400 0.196 0 1.000";

	 // Dynamic properties defined by the scripts
	image = flashgrenadeImage;
	canDrop = true;
};

datablock ShapeBaseImageData(flashgrenadeImage)
{
   // Basic Item properties
   shapeFile = "./flashgrenade.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   //eyeOffset = "0.1 0.2 -0.55";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = flashgrenadeItem;
   ammo = " ";
   projectile = flashgrenadeProjectile;
   projectileType = Projectile;

   	casing = flashgrenadePinDebris;
	shellExitDir        = "-2.0 1.0 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = false;
   colorShiftColor = "0.400 0.196 0 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.1;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Pindrop";
	stateAllowImageChange[1]	= true;

	stateName[2]			= "Pindrop";
	stateTransitionOnTimeout[2]	= "Pinfallen";
	stateAllowImageChange[2]	= false;
	stateTimeoutValue[2]		= 0.2;
	stateSound[2]				= flashgrenadeFireSound;
	stateSequence[2]                = "Pinhide";
	stateEjectShell[2]       = true;

	stateName[3]			= "Pinfallen";
	stateTransitionOnTriggerDown[3]	= "Charge";
	stateAllowImageChange[3]	= false;
	
	stateName[4]                    = "Charge";
	stateTransitionOnTimeout[4]	= "Armed";
	stateTimeoutValue[4]            = 0.7;
	stateWaitForTimeout[4]		= false;
	stateTransitionOnTriggerUp[4]	= "AbortCharge";
	stateScript[4]                  = "onCharge";
	stateAllowImageChange[4]        = false;
	
	stateName[5]			= "AbortCharge";
	stateTransitionOnTimeout[5]	= "Pinfallen";
	stateTimeoutValue[5]		= 0.3;
	stateWaitForTimeout[5]		= true;
	stateScript[5]			= "onAbortCharge";
	stateAllowImageChange[5]	= false;

	stateName[6]			= "Armed";
	stateTransitionOnTriggerUp[6]	= "Fire";
	stateAllowImageChange[6]	= false;

	stateName[7]			= "Fire";
	stateTransitionOnTimeout[7]	= "Done";
	stateTimeoutValue[7]		= 0.5;
	stateFire[7]			= true;
	stateSequence[7]		= "fire";
	stateScript[7]			= "onFire";
	stateWaitForTimeout[7]		= true;
	stateAllowImageChange[7]	= false;

	stateName[8]					= "Done";
	stateScript[8]					= "onDone";

};

package flashGrenadePackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "flashGrenadeItem" && %col.canPickup)
		{
			for(%i=0;%i<%this.maxTools;%i++)
			{
				%item = %obj.tool[%i];
				if(%item $= 0 || %item $= "")
				{
					%freeSlot = 1;
					break;
				}
			}

			if(%freeSlot)
			{
				%obj.pickup(%col);
				return;
			}
		}
		Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(flashGrenadePackage);

function flashgrenadeImage::onCharge(%this, %obj, %slot)
{
	%obj.playthread(2, spearReady);
	%obj.lastflashSlot = %obj.currTool;
}

function flashgrenadeImage::onAbortCharge(%this, %obj, %slot)
{
	%obj.playthread(2, root);
}

function flashgrenadeProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
	serverPlay3D(flashgrenadeBounceSound,%obj.getTransform());
}

function flashgrenadeImage::onFire(%this, %obj, %slot)
{
	%obj.playthread(2, spearThrow);
	Parent::OnFire(%this, %obj, %slot);

	%currSlot = %obj.lastflashSlot;
	%obj.tool[%currSlot] = 0;
	%obj.weaponCount--;
	messageClient(%obj.client,'MsgItemPickup','',%currSlot,0);
	serverCmdUnUseTool(%obj.client);
}

function flashgrenadeImage::onDone(%this,%obj,%slot)
{
	%obj.unMountImage(%slot);
}

datablock DecalData(flashGrenadeIcon)
{
   textureName = "Add-Ons/Weapon_flashGrenade/icon_flashgrenade";
};

//-------------------------------------
//- The math is originally by Nixill
//- He gave me permission to use it
//-------------------------------------

function calculateAngle(%player,%pos)
{
	//Get the players forward vector.
	%fv=%player.getEyeVector();
	
	//Get xyz.
	%x=getWord(%fv,0);
	%y=getWord(%fv,1);
	%z=getWord(%fv,2);
	
	//Get the vector from you to the target.
	%vv=vectorNormalize(vectorSub(%pos,%player.getPosition()));
	
	//Get xyz.
	%xx=getWord(%vv,0);
	%yy=getWord(%vv,1);
	%zz=getWord(%vv,2);
	
	//Get stuff.
	%srot=mATan(%x,%y);
	%grot=mATan(%xx,%yy);
	
	%xyl=msqrt(%x*%x+%y*%y);
	%xyll=msqrt(%xx*%xx+%yy*%yy);
	
	%pelev=mATan(%z,%xyl);
	%telev=mATan(%zz,%xyll);
	
	//Get rotations.
	%rot=%grot-%srot;
	
	%elev=%pelev-%telev;
	
	//Since it's in Radians and not Degrees, change it to degrees for more comfortable usage

	%Hangle = mRadtoDeg(%rot); //Horizontal Angle
	%Vangle = mRadtoDeg(%elev); //Vertical Angle

	return %Hangle SPC %Vangle;
}

//checks to see if the player's eyepoint is obstructed, if so, they don't get the white out or timescale effect.
function isObstruction(%pos,%player)
{
   %object = ContainerRayCast(%pos,%player.getEyePoint(), $TypeMasks::FxBrickObjectType | $TypeMasks::PlayerObjectType | $TypeMasks::InteriorObjectType | $TypeMasks::VehicleObjectType, %player);

   %obstr = getWord(%object,0);
   if(isObject(%obstr) && %obstr.getDatablock().getName() !$= "brick4x1x5windowData")
      return 1;
   else
      return 0;
}

function flashGrenadeProjectile::onExplode(%this,%obj)
{
   parent::onExplode(%this, %obj);
   initContainerRadiusSearch(%obj.getPosition(),23,$TypeMasks::PlayerObjectType);
   while((%target = ContainerSearchNext()) != 0)
   {
      if(!isObstruction(%obj.getPosition(),%target) && isObject(%obj.client.minigame) && %obj.client.minigame == %target.client.minigame && %obj.client.minigame.weapondamage == 1)
      {
         %angle = calculateAngle(%target,%obj.getPosition());
         if(%angle < 100 && %angle > -100 || %angle > -360 && %angle < -260 || %angle < 360 && %angle > 260)
         {
	    if(%angle < 0)
	       %angle = mAbs(%angle);

	    if(%angle > 180)
	       %angle = %angle/6;

	    if(%angle < 10)
	    {
	       %start = 2;
	    }
	    else
	    {
	       %start = mFloatLength(1/%angle*25,4);
	    }

	    if(%start < 0.2)
	       %start = 0.2;
	    %target.setWhiteout(%start);
	    %sched = %start*1000;

	    //%target.client.play2D(FlashDeafenSound); //Taken out due to a bug with an unknown cause (Un-comment this line along with the datablock at the top to restore this feature)
         }
      }
   }
}

package isHost
{
      function GameConnection::autoAdminCheck(%cl)
   {
      %cl.isHost = (%cl.isLocalConnection() || %cl.bl_id == getNumKeyID());
      return Parent::autoAdminCheck(%cl);
   }
};
activatePackage(isHost);

//Thanks Trewse for the isHost thingy